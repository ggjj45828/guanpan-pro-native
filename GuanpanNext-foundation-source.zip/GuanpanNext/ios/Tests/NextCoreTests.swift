import XCTest
@testable import GuanpanNextCore

final class NextCoreTests: XCTestCase {
    let now = Date(timeIntervalSince1970: 1792375200)
    func quote(time: Date, price: Decimal = 1.4) -> NextQuote {
        NextQuote(code: "159941", name: "纳指ETF", price: price, previousClose: 1.4, time: time, source: "test")
    }
    func testMissingQuoteDoesNotPretendAssetTotal() {
        var book = NextBook(); book.cash = 100
        book.positions = [NextPosition(code: "159941", name: "纳指ETF", units: 100, bookCost: 120)]
        XCTAssertNil(book.total(using: [:]))
        XCTAssertEqual(book.total(using: ["159941": quote(time: now)]), 240)
        XCTAssertEqual(book.positions[0].costPerUnit, 1.2)
    }
    func testBudgetDoesNotDependOnRealCashOrMutateBook() throws {
        let book = NextBook(); let goal = NextGoal()
        let result = try NextResearch.prepare(book: book, goal: goal, quotes: [:], now: now)
        XCTAssertEqual(result.options.count, 2)
        XCTAssertEqual(book.cash, 0)
        XCTAssertEqual(result.origin, "本地规则检查")
    }
    func testModelEvidenceMustExistAndDescribeTradeoff() throws {
        let result = try NextResearch.prepare(book: NextBook(), goal: NextGoal(), quotes: [:], now: now)
        XCTAssertEqual(try NextResearch.acceptModelOptions(result.options, evidence: result.evidence).count, 2)
        let fake = NextOption(id: "fake", title: "方案", rationale: "理由", tradeoff: "未知", evidenceIDs: ["invented"])
        XCTAssertThrowsError(try NextResearch.acceptModelOptions([fake, result.options[0]], evidence: result.evidence))
    }
    func testDecimalFeesReservationAndCancellation() throws {
        var sim = NextExperiment()
        try sim.place(code: "159941", limit: 1.5, units: 100, at: now, until: now.addingTimeInterval(3600))
        XCTAssertEqual(sim.available, Decimal(string: "9849.90"))
        sim.cancel(sim.orders[0].id)
        XCTAssertEqual(sim.available, 10000)
    }
    func testNoFillFromOldFuturePreorderOrClosedSession() throws {
        var sim = NextExperiment()
        try sim.place(code: "159941", limit: 1.5, units: 100, at: now, until: now.addingTimeInterval(3600))
        for stamp in [now.addingTimeInterval(-1000), now, now.addingTimeInterval(60)] {
            sim.observe(quote(time: stamp), now: now, marketOpen: true)
        }
        sim.observe(quote(time: now.addingTimeInterval(1)), now: now.addingTimeInterval(1), marketOpen: false)
        XCTAssertEqual(sim.cash, 10000)
        XCTAssertTrue(sim.positions.isEmpty)
    }
    func testFillOncePaysLimitAndFee() throws {
        var sim = NextExperiment()
        try sim.place(code: "159941", limit: 1.5, units: 100, at: now, until: now.addingTimeInterval(3600))
        let q = quote(time: now.addingTimeInterval(1))
        sim.observe(q, now: q.time, marketOpen: true)
        let copy = sim
        sim.observe(q, now: q.time, marketOpen: true)
        XCTAssertEqual(sim, copy)
        XCTAssertEqual(sim.cash, Decimal(string: "9849.90"))
        XCTAssertEqual(sim.positions[0].bookCost, Decimal(string: "150.10"))
    }
    func testInvalidOrderAndOverspendRejected() throws {
        var sim = NextExperiment(); sim.cash = 200
        XCTAssertThrowsError(try sim.place(code: "159941", limit: 1, units: 99, at: now, until: now.addingTimeInterval(60)))
        XCTAssertThrowsError(try sim.place(code: "600000", limit: 1, units: 100, at: now, until: now.addingTimeInterval(60)))
        try sim.place(code: "159941", limit: 1.5, units: 100, at: now, until: now.addingTimeInterval(60))
        XCTAssertThrowsError(try sim.place(code: "159941", limit: 1.5, units: 100, at: now, until: now.addingTimeInterval(60)))
        sim.expire(at: now.addingTimeInterval(60))
        XCTAssertEqual(sim.available, 200)
    }
    func testBookAndSimulationIndependentRoundTrips() throws {
        let book = NextBook(), sim = NextExperiment()
        XCTAssertEqual(try JSONDecoder().decode(NextBook.self, from: JSONEncoder().encode(book)), book)
        XCTAssertEqual(try JSONDecoder().decode(NextExperiment.self, from: JSONEncoder().encode(sim)), sim)
    }
}
