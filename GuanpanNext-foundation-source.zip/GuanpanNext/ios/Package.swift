// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "GuanpanNextCore", products: [.library(name: "GuanpanNextCore", targets: ["GuanpanNextCore"])], targets: [
    .target(name: "GuanpanNextCore", path: "Sources", sources: ["NextCore.swift"]),
    .testTarget(name: "GuanpanNextCoreTests", dependencies: ["GuanpanNextCore"], path: "Tests")
])
