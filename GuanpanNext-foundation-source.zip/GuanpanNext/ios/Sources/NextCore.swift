import Foundation

enum NextError: LocalizedError {
    case invalid(String)
    var errorDescription: String? { if case .invalid(let text) = self { return text }; return nil }
}

enum NextMoney {
    static func parse(_ text: String) throws -> Decimal {
        guard let value = Decimal(string: text, locale: Locale(identifier: "en_US_POSIX")), !value.isNaN else {
            throw NextError.invalid("金额格式无效")
        }
        return value
    }
    static func text(_ value: Decimal, digits: Int = 2) -> String {
        let formatter = NumberFormatter()
        formatter.locale = Locale(identifier: "zh_CN")
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = digits
        formatter.maximumFractionDigits = digits
        return formatter.string(from: NSDecimalNumber(decimal: value)) ?? "--"
    }
}

// New schema: no OTC position, subscription, redemption or automatic DCA type.
struct NextPosition: Codable, Identifiable, Equatable {
    var id: String { code }
    let code: String
    var name: String
    var units: Int
    var bookCost: Decimal
    var costPerUnit: Decimal { units > 0 ? bookCost / Decimal(units) : 0 }
}
struct NextFill: Codable, Identifiable, Equatable {
    var id = UUID()
    var date: Date
    var code: String
    var side: String
    var units: Int
    var price: Decimal
    var fee: Decimal
    var realized: Decimal
}
struct NextAssetPoint: Codable, Identifiable, Equatable {
    var id = UUID()
    let date: Date
    let total: Decimal
    let externalFlow: Decimal
}
struct NextBook: Codable, Equatable {
    var schemaVersion = 1
    var id = UUID()
    var cash: Decimal = 0
    var positions: [NextPosition] = []
    var fills: [NextFill] = []
    // Only snapshots recorded under the new securities schema belong here.
    var history: [NextAssetPoint] = []
    var importedAt: Date?
    func validate() throws {
        guard schemaVersion == 1, !cash.isNaN, cash >= 0,
              Set(positions.map(\.code)).count == positions.count,
              positions.allSatisfy({ $0.code.count == 6 && $0.code.allSatisfy(\.isNumber) && $0.units >= 0 && !$0.bookCost.isNaN && $0.bookCost >= 0 }) else {
            throw NextError.invalid("账本校验失败：现金、持仓或版本无效")
        }
    }
    func total(using quotes: [String: NextQuote]) -> Decimal? {
        var total = cash
        for p in positions where p.units > 0 {
            guard let q = quotes[p.code] else { return nil }
            total += q.price * Decimal(p.units)
        }
        return total
    }
}
struct NextQuote: Codable, Identifiable, Equatable {
    var id: String { code }
    let code: String
    let name: String
    let price: Decimal
    let previousClose: Decimal
    let time: Date
    let source: String
    var changePercent: Decimal? { previousClose > 0 ? (price / previousClose - 1) * 100 : nil }
    func isFresh(at now: Date) -> Bool { time <= now && now.timeIntervalSince(time) <= 120 && price > 0 }
}
struct NextGoal: Codable, Equatable {
    var years = 10
    var monthlyBudget: Decimal = 1000
    var concentrationLimit: Decimal = 40
    func validate() throws {
        guard years > 0, years <= 50, !monthlyBudget.isNaN, monthlyBudget >= 0,
              concentrationLimit > 0, concentrationLimit <= 100 else { throw NextError.invalid("目标或预算无效") }
    }
}
struct NextEvidence: Codable, Identifiable, Equatable {
    var id: String
    let title: String
    let detail: String
    let level: String
    let observedAt: Date
}
struct NextOption: Codable, Identifiable, Equatable {
    var id: String
    let title: String
    let rationale: String
    let tradeoff: String
    let evidenceIDs: [String]
}
struct NextDecision: Codable, Identifiable, Equatable {
    var id = UUID()
    let createdAt: Date
    var title: String
    var evidence: [NextEvidence]
    var options: [NextOption]
    var selectedOption: String?
    var review: String = ""
    var status: String = "待比较"
    let origin: String
}
enum NextResearch {
    // Local arithmetic and data checks are explicitly not model-generated AI.
    static func prepare(book: NextBook, goal: NextGoal, quotes: [String: NextQuote], now: Date) throws -> NextDecision {
        try book.validate(); try goal.validate()
        var evidence = [NextEvidence(id: "budget", title: "新增资金独立规划", detail: "每月预算 ¥\(NextMoney.text(goal.monthlyBudget))；不占用或改动真实现金。", level: "事实", observedAt: now)]
        let missing = book.positions.filter { $0.units > 0 && quotes[$0.code]?.isFresh(at: now) != true }
        evidence.append(NextEvidence(id: "quotes", title: missing.isEmpty ? "报价检查通过" : "行情证据待补齐",
                                     detail: missing.isEmpty ? "所有现有持仓报价在两分钟内。" : "\(missing.count) 只持仓没有新鲜报价；不生成带价交易方案。", level: missing.isEmpty ? "事实" : "缺口", observedAt: now))
        if let total = book.total(using: quotes), total > 0 {
            let largest = book.positions.map { Decimal($0.units) * (quotes[$0.code]?.price ?? 0) / total * 100 }.max() ?? 0
            evidence.append(NextEvidence(id: "concentration", title: "当前单只最高占比", detail: "\(NextMoney.text(largest))%；你设置的检查阈值为 \(NextMoney.text(goal.concentrationLimit))%。", level: largest > goal.concentrationLimit ? "待核对" : "事实", observedAt: now))
        }
        let options = [
            NextOption(id: "wait", title: "暂不调整，补齐证据", rationale: "保留当前仓位，先核对行情与预算。", tradeoff: "维持现有集中度，也可能错过部分行情。", evidenceIDs: ["quotes"]),
            NextOption(id: "budget", title: "用新增资金逐月靠近目标", rationale: "把每月预算单独用于下一步配置研究；不足一手时先累计。", tradeoff: "调整较慢，需要持续投入；没有收益保证。", evidenceIDs: ["budget", "quotes"])
        ]
        return NextDecision(createdAt: now, title: "本次账户研究", evidence: evidence, options: options, origin: "本地规则检查")
    }
    static func acceptModelOptions(_ options: [NextOption], evidence: [NextEvidence]) throws -> [NextOption] {
        let known = Set(evidence.map(\.id))
        guard (2...4).contains(options.count), Set(options.map(\.id)).count == options.count,
              options.allSatisfy({ !$0.title.isEmpty && !$0.rationale.isEmpty && !$0.tradeoff.isEmpty && !$0.evidenceIDs.isEmpty && Set($0.evidenceIDs).isSubset(of: known) }) else {
            throw NextError.invalid("AI 方案缺少依据、取舍说明或引用了不存在的证据，未采用")
        }
        return options
    }
}

// Entirely independent experiment ledger. No real-book reference or write API.
struct NextExperiment: Codable, Equatable {
    struct Order: Codable, Identifiable, Equatable {
        var id = UUID()
        let code: String
        let limit: Decimal
        let units: Int
        let placedAt: Date
        let expiresAt: Date
        var state = "等待"
    }
    var cash: Decimal = 10000
    var positions: [NextPosition] = []
    var orders: [Order] = []
    static let fee = Decimal(string: "0.10")!
    var reserved: Decimal { orders.filter { $0.state == "等待" }.reduce(0) { $0 + $1.limit * Decimal($1.units) + Self.fee } }
    var available: Decimal { cash - reserved }
    mutating func place(code: String, limit: Decimal, units: Int, at now: Date, until expiry: Date) throws {
        expire(at: now)
        guard code.count == 6, code.allSatisfy(\.isNumber), ["15", "16", "51", "56", "58"].contains(String(code.prefix(2))),
              !limit.isNaN, limit > 0, limit <= 100000, units > 0, units <= 100000000, units % 100 == 0,
              expiry > now, limit * Decimal(units) + Self.fee <= available else { throw NextError.invalid("仅支持ETF整手限价模拟，请核对价格、数量、有效期和虚拟可用资金") }
        orders.append(Order(code: code, limit: limit, units: units, placedAt: now, expiresAt: expiry))
    }
    mutating func expire(at now: Date) {
        for i in orders.indices where orders[i].state == "等待" && orders[i].expiresAt <= now { orders[i].state = "到期" }
    }
    mutating func cancel(_ id: UUID) {
        if let i = orders.firstIndex(where: { $0.id == id && $0.state == "等待" }) { orders[i].state = "已撤销" }
    }
    mutating func observe(_ quote: NextQuote, now: Date, marketOpen: Bool) {
        expire(at: now)
        guard marketOpen, quote.isFresh(at: now) else { return }
        for i in orders.indices where orders[i].state == "等待" && orders[i].code == quote.code {
            let o = orders[i]
            guard quote.time > o.placedAt, quote.time < o.expiresAt, quote.price <= o.limit else { continue }
            let amount = o.limit * Decimal(o.units) + Self.fee
            guard amount <= cash else { continue }
            cash -= amount
            if let j = positions.firstIndex(where: { $0.code == o.code }) { positions[j].units += o.units; positions[j].bookCost += amount }
            else { positions.append(NextPosition(code: o.code, name: quote.name, units: o.units, bookCost: amount)) }
            orders[i].state = "触价模拟"
        }
    }
}

